// CYG Finance Agent — runs only on the internal app's own pages (see manifest.json).
//
// The extension never signs in by itself: it borrows the session the internal app already
// has (`localStorage.token`, written by AuthContext). This script hands that token to the
// background worker, which asks the internal API for a ticket to the agents server.
// A sign-out clears the token, and the background worker disconnects.

(() => {
  let last;

  function report() {
    let token = null;
    try {
      token = window.localStorage.getItem('token');
    } catch {
      token = null;
    }
    if (token === last) return;
    last = token;
    try {
      chrome.runtime.sendMessage({
        type: 'session',
        token,
        origin: window.location.origin,
      });
    } catch {
      // the extension was reloaded — this page's script is orphaned; nothing to do
    }
  }

  report();
  // `storage` fires only in OTHER tabs, so the same tab's sign-in / sign-out is polled.
  window.addEventListener('storage', report);
  setInterval(report, 5000);
})();
