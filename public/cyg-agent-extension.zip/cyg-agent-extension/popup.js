// CYG Finance Agent — the toolbar popup: who is signed in and whether the agents can reach
// this Chrome.

const LABELS = {
  connected: 'Connected — the agents can open tabs here',
  connecting: 'Connecting…',
  error: 'Not connected',
  'signed-out': 'Not signed in',
};

const $ = (id) => document.getElementById(id);

async function render() {
  const s = await chrome.runtime.sendMessage({ type: 'get-status' });
  if (!s) return;
  $('dot').className = `dot ${s.status}`;
  $('status').textContent = LABELS[s.status] ?? s.status;
  $('user').textContent = s.user ? `${s.user.name}${s.user.email ? ` · ${s.user.email}` : ''}` : '';
  $('error').hidden = !s.error;
  $('error').textContent = s.error ?? '';
  const signedOut = s.status === 'signed-out';
  $('help').hidden = !signedOut;
  $('open').hidden = !signedOut;
  if (s.origin) $('open').href = s.origin;
  $('reconnect').hidden = signedOut || s.status === 'connected';
  $('version').textContent = `v${s.version}`;
}

$('reconnect').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'reconnect' });
  void render();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'status-changed') void render();
});

void render();
