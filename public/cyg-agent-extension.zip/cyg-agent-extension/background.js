// CYG Finance Agent — the background service worker.
//
// 1. content.js hands over the internal app's session token (the user is signed in there).
// 2. We call the internal API: POST <app>/api/extension/register {extensionId, version}
//    → {wsUrl, ticket, user}. The internal API registers this extension on the agents
//    server for every company the user works, and the agents server signs the ticket.
// 3. We keep a websocket to the agents server (wsUrl), first frame {type:'auth', ticket}.
// 4. The agents send commands — {type:'cmd', id, action, args} — and we answer
//    {type:'result', id, ok, data | error}. Actions: open, snapshot, click, type, press,
//    tabs, close. The agent can only drive tabs IT opened (remembered per agent + name).
//
// Clicks, typing and keys go through the Chrome DevTools protocol (chrome.debugger), so the
// page sees real, trusted input. Chrome shows a "being debugged" bar while it is attached;
// we detach after a short idle.

const VERSION = chrome.runtime.getManifest().version;
const PING_MS = 20_000;
const REGISTER_EVERY_MS = 10 * 60_000;
const DEBUGGER_IDLE_MS = 60_000;
const MAX_TEXT = 12_000;
const MAX_ELEMENTS = 250;

/** In memory; the worker may restart, so everything that matters is in chrome.storage. */
const state = {
  ws: null,
  status: 'signed-out', // signed-out | connecting | connected | error
  error: null,
  retry: 0,
  retryTimer: null,
  pingTimer: null,
  lastToken: null,
  lastRegisterAt: 0,
};

// ── Status ────────────────────────────────────────────────────────────────

function setStatus(status, error = null) {
  state.status = status;
  state.error = error;
  const badge =
    status === 'connected' ? 'ON' : status === 'connecting' ? '…' : status === 'error' ? '!' : '';
  chrome.action.setBadgeText({ text: badge }).catch(() => undefined);
  chrome.action
    .setBadgeBackgroundColor({ color: status === 'connected' ? '#3BBFB4' : '#B45309' })
    .catch(() => undefined);
  chrome.runtime.sendMessage({ type: 'status-changed' }).catch(() => undefined);
}

async function publicStatus() {
  const { session } = await chrome.storage.local.get('session');
  return {
    status: state.status,
    error: state.error,
    user: session?.user ?? null,
    origin: session?.origin ?? null,
    version: VERSION,
  };
}

// ── Signing in with the internal app's session ────────────────────────────

async function onSession(token, origin) {
  const { session } = await chrome.storage.local.get('session');
  if (!token) {
    // Signed out of the app this session came from → disconnect.
    if (session && session.origin === origin) {
      await chrome.storage.local.remove('session');
      state.lastToken = null;
      disconnect();
      setStatus('signed-out');
    }
    return;
  }
  const fresh =
    token === state.lastToken && Date.now() - state.lastRegisterAt < REGISTER_EVERY_MS;
  if (fresh && session?.ticket) {
    if (!state.ws) connect();
    return;
  }
  await register(token, origin);
}

async function register(token, origin) {
  state.lastToken = token;
  state.lastRegisterAt = Date.now();
  try {
    const res = await fetch(`${origin}/api/extension/register`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ extensionId: chrome.runtime.id, version: VERSION }),
    });
    if (res.status === 401) {
      setStatus('signed-out', 'Your internal app session ended — sign in again.');
      return;
    }
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      setStatus('error', `Could not register (HTTP ${res.status}) ${text.slice(0, 200)}`);
      return;
    }
    const body = await res.json();
    await chrome.storage.local.set({
      session: {
        origin,
        wsUrl: body.wsUrl,
        ticket: body.ticket,
        expiresAt: body.expiresAt,
        user: body.user,
      },
    });
    disconnect();
    connect();
  } catch (err) {
    setStatus('error', `Could not reach the internal app: ${err?.message ?? err}`);
  }
}

// ── The websocket to the agents server ────────────────────────────────────

function disconnect() {
  clearTimeout(state.retryTimer);
  clearInterval(state.pingTimer);
  state.retryTimer = null;
  state.pingTimer = null;
  if (state.ws) {
    const ws = state.ws;
    state.ws = null;
    try {
      ws.onclose = null;
      ws.close();
    } catch {
      // already closed
    }
  }
}

async function connect() {
  if (state.ws) return;
  const { session } = await chrome.storage.local.get('session');
  if (!session?.ticket || !session?.wsUrl) {
    setStatus('signed-out');
    return;
  }
  if (session.expiresAt && session.expiresAt * 1000 < Date.now()) {
    setStatus('signed-out', 'Open the internal app once to sign the extension in again.');
    return;
  }
  setStatus('connecting');
  let ws;
  try {
    ws = new WebSocket(session.wsUrl);
  } catch (err) {
    setStatus('error', `Bad agents server address: ${err?.message ?? err}`);
    return;
  }
  state.ws = ws;
  ws.onopen = () => ws.send(JSON.stringify({ type: 'auth', ticket: session.ticket }));
  ws.onmessage = (event) => {
    let msg;
    try {
      msg = JSON.parse(event.data);
    } catch {
      return;
    }
    if (msg.type === 'hello') {
      state.retry = 0;
      setStatus('connected');
      clearInterval(state.pingTimer);
      state.pingTimer = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) ws.send('{"type":"ping"}');
      }, PING_MS);
    } else if (msg.type === 'cmd') {
      void runCommand(ws, msg);
    }
  };
  ws.onclose = async (event) => {
    clearInterval(state.pingTimer);
    state.ws = null;
    if (event.code === 4401 || event.code === 4403) {
      // The ticket was refused (expired / revoked): the next visit to the app re-registers.
      await chrome.storage.local.remove('session');
      state.lastToken = null;
      setStatus('signed-out', 'Open the internal app once to sign the extension in again.');
      return;
    }
    setStatus('connecting', 'Reconnecting…');
    scheduleReconnect();
  };
  ws.onerror = () => undefined; // onclose follows
}

function scheduleReconnect() {
  clearTimeout(state.retryTimer);
  const delay = Math.min(30_000, 1000 * 2 ** state.retry);
  state.retry += 1;
  state.retryTimer = setTimeout(() => void connect(), delay);
}

// ── The agent's tabs ──────────────────────────────────────────────────────

/** `agentId:name` → tabId, kept in session storage (the worker may restart). */
async function tabMap() {
  const { agentTabs } = await chrome.storage.session.get('agentTabs');
  return agentTabs ?? {};
}

async function saveTabMap(map) {
  await chrome.storage.session.set({ agentTabs: map });
}

function tabName(raw) {
  const name = String(raw ?? 'main')
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '')
    .slice(0, 32);
  return name || 'main';
}

/** The live tab the agent opened under that name, or null. */
async function agentTab(agentId, name) {
  const map = await tabMap();
  const tabId = map[`${agentId}:${tabName(name)}`];
  if (!tabId) return null;
  try {
    return await chrome.tabs.get(tabId);
  } catch {
    delete map[`${agentId}:${tabName(name)}`];
    await saveTabMap(map);
    return null;
  }
}

async function requireTab(agentId, name) {
  const tab = await agentTab(agentId, name);
  if (!tab) {
    throw new Error(
      `No tab "${tabName(name)}" of yours is open in this Chrome — open it first with user_tab_open.`,
    );
  }
  return tab;
}

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const map = await tabMap();
  let changed = false;
  for (const [key, id] of Object.entries(map)) {
    if (id === tabId) {
      delete map[key];
      changed = true;
    }
  }
  if (changed) await saveTabMap(map);
  attached.delete(tabId);
});

function waitForLoad(tabId, timeoutMs = 30_000) {
  return new Promise((resolve) => {
    const done = () => {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    };
    const listener = (id, info) => {
      if (id === tabId && info.status === 'complete') done();
    };
    const timer = setTimeout(done, timeoutMs);
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs
      .get(tabId)
      .then((t) => {
        if (t.status === 'complete') done();
      })
      .catch(done);
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** After a click / key: give a navigation the chance to start, then wait for it. */
async function settle(tabId) {
  await sleep(700);
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab?.status === 'loading') await waitForLoad(tabId, 15_000);
  await sleep(300);
}

// ── Reading the page (runs IN the page) ───────────────────────────────────

function pageSnapshot(maxText, maxElements) {
  const SELECTOR =
    'a[href], button, input, select, textarea, [role="button"], [role="link"], [role="tab"], [role="menuitem"], [role="option"], [role="checkbox"], [role="switch"], [role="combobox"], [contenteditable="true"]';
  const w = window;
  for (const old of Array.from(document.querySelectorAll('[data-cyg-ref]'))) {
    if (!old.matches(SELECTOR)) old.removeAttribute('data-cyg-ref');
  }
  if (w.__cygRefSeq === undefined) {
    let max = 0;
    for (const el of Array.from(document.querySelectorAll('[data-cyg-ref]'))) {
      max = Math.max(max, Number(el.getAttribute('data-cyg-ref')) || 0);
    }
    w.__cygRefSeq = max;
  }
  const elements = [];
  const used = new Set();
  for (const el of Array.from(document.querySelectorAll(SELECTOR))) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    const hidden =
      rect.width === 0 ||
      rect.height === 0 ||
      style.visibility === 'hidden' ||
      style.display === 'none' ||
      el.type === 'hidden';
    if (hidden || elements.length >= maxElements) continue;
    let ref = Number(el.getAttribute('data-cyg-ref')) || 0;
    if (!ref || used.has(ref)) {
      w.__cygRefSeq += 1;
      ref = w.__cygRefSeq;
      el.setAttribute('data-cyg-ref', String(ref));
    }
    used.add(ref);
    const tag = el.tagName.toLowerCase();
    const role = el.getAttribute('role');
    const kind =
      tag === 'input'
        ? `input:${el.type || 'text'}`
        : tag === 'a'
          ? 'link'
          : role && tag !== 'button'
            ? role
            : tag;
    const label =
      el.getAttribute('aria-label') ||
      (el.labels && el.labels[0] && el.labels[0].innerText) ||
      el.placeholder ||
      el.innerText ||
      el.name ||
      el.getAttribute('title') ||
      '';
    const states = [];
    const expanded = el.getAttribute('aria-expanded');
    if (expanded === 'true') states.push('expanded');
    if (expanded === 'false') states.push('collapsed');
    if (el.getAttribute('aria-selected') === 'true') states.push('selected');
    const checkable = tag === 'input' && (el.type === 'checkbox' || el.type === 'radio');
    if (checkable) states.push(el.checked ? 'checked' : 'not checked');
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') states.push('disabled');
    let value = '';
    if (tag === 'input' && !checkable) {
      if (el.type === 'password') value = el.value ? ' = (filled)' : '';
      else if (el.value) value = ` = "${String(el.value).slice(0, 60)}"`;
    } else if (tag === 'textarea' && el.value) {
      value = ` = "${String(el.value).slice(0, 60)}"`;
    } else if (tag === 'select') {
      const chosen = el.options[el.selectedIndex]?.text;
      if (chosen) value = ` = "${chosen.slice(0, 60)}"`;
    }
    elements.push(
      `[${ref}] ${kind} ${String(label).replace(/\s+/g, ' ').trim().slice(0, 80)}${states.length ? ` (${states.join(', ')})` : ''}${value}`,
    );
  }
  const text = (document.body?.innerText ?? '').replace(/\n{3,}/g, '\n\n');
  return {
    url: location.href,
    title: document.title,
    text: text.length > maxText ? `${text.slice(0, maxText)}\n… (page text cut)` : text,
    elements,
  };
}

/** Scroll element [ref] into view; its centre in CSS pixels, or why not. */
function elementPoint(ref) {
  const el = document.querySelector(`[data-cyg-ref="${ref}"]`);
  if (!el) return { error: `Element [${ref}] is not on the page any more — look at the page again.` };
  el.scrollIntoView({ block: 'center', inline: 'center' });
  const r = el.getBoundingClientRect();
  if (r.width === 0 || r.height === 0) return { error: `Element [${ref}] is hidden now.` };
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
}

/** Focus field [ref] and empty it, so typed text replaces what was there. */
function focusField(ref) {
  const el = document.querySelector(`[data-cyg-ref="${ref}"]`);
  if (!el) return { error: `Field [${ref}] is not on the page any more — look at the page again.` };
  const tag = el.tagName.toLowerCase();
  const editable = el.isContentEditable;
  if (tag !== 'input' && tag !== 'textarea' && tag !== 'select' && !editable) {
    return { error: `[${ref}] is not a field you can type into.` };
  }
  el.scrollIntoView({ block: 'center' });
  el.focus();
  if (editable) {
    const range = document.createRange();
    range.selectNodeContents(el);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  } else if (tag !== 'select') {
    el.select?.();
  }
  return { ok: true };
}

/** Without the debugger (it was refused): set the value and fire the events by hand. */
function fallbackType(ref, text) {
  const el = document.querySelector(`[data-cyg-ref="${ref}"]`);
  if (!el) return false;
  if (el.isContentEditable) {
    el.textContent = text;
  } else {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value')?.set?.call(el, text);
  }
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}

function fallbackClick(ref) {
  const el = document.querySelector(`[data-cyg-ref="${ref}"]`);
  if (!el) return false;
  el.click();
  return true;
}

async function inPage(tabId, func, args = []) {
  const [result] = await chrome.scripting.executeScript({ target: { tabId }, func, args });
  return result?.result;
}

async function snapshot(tabId) {
  const snap = await inPage(tabId, pageSnapshot, [MAX_TEXT, MAX_ELEMENTS]);
  if (!snap) throw new Error('Could not read this page (Chrome does not allow it here).');
  return snap;
}

// ── Trusted input through the DevTools protocol ───────────────────────────

const attached = new Map(); // tabId → idle timer

async function withDebugger(tabId) {
  if (!attached.has(tabId)) {
    await chrome.debugger.attach({ tabId }, '1.3');
  }
  clearTimeout(attached.get(tabId));
  attached.set(
    tabId,
    setTimeout(() => {
      attached.delete(tabId);
      chrome.debugger.detach({ tabId }).catch(() => undefined);
    }, DEBUGGER_IDLE_MS),
  );
}

chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId) {
    clearTimeout(attached.get(source.tabId));
    attached.delete(source.tabId);
  }
});

const cdp = (tabId, method, params) => chrome.debugger.sendCommand({ tabId }, method, params);

const KEYS = {
  Enter: { code: 'Enter', keyCode: 13, text: '\r' },
  Tab: { code: 'Tab', keyCode: 9 },
  Escape: { code: 'Escape', keyCode: 27 },
  Backspace: { code: 'Backspace', keyCode: 8 },
  Delete: { code: 'Delete', keyCode: 46 },
  Space: { code: 'Space', keyCode: 32, text: ' ', key: ' ' },
  ArrowUp: { code: 'ArrowUp', keyCode: 38 },
  ArrowDown: { code: 'ArrowDown', keyCode: 40 },
  ArrowLeft: { code: 'ArrowLeft', keyCode: 37 },
  ArrowRight: { code: 'ArrowRight', keyCode: 39 },
  PageUp: { code: 'PageUp', keyCode: 33 },
  PageDown: { code: 'PageDown', keyCode: 34 },
  Home: { code: 'Home', keyCode: 36 },
  End: { code: 'End', keyCode: 35 },
};

async function pressKey(tabId, key) {
  const k = KEYS[key];
  if (!k) throw new Error(`Unknown key "${key}". Use one of: ${Object.keys(KEYS).join(', ')}.`);
  const base = {
    key: k.key ?? key,
    code: k.code,
    windowsVirtualKeyCode: k.keyCode,
    nativeVirtualKeyCode: k.keyCode,
  };
  await cdp(tabId, 'Input.dispatchKeyEvent', {
    type: k.text ? 'keyDown' : 'rawKeyDown',
    ...base,
    ...(k.text ? { text: k.text, unmodifiedText: k.text } : {}),
  });
  await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', ...base });
}

async function click(tabId, ref) {
  const point = await inPage(tabId, elementPoint, [ref]);
  if (!point || point.error) throw new Error(point?.error ?? 'Could not find the element.');
  try {
    await withDebugger(tabId);
    const at = { x: point.x, y: point.y, button: 'left', clickCount: 1 };
    await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: at.x, y: at.y });
    await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', ...at });
    await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', ...at });
  } catch {
    // The debugger was refused (DevTools open on that tab): a plain DOM click instead.
    if (!(await inPage(tabId, fallbackClick, [ref]))) throw new Error(`Could not click [${ref}].`);
  }
}

async function type(tabId, ref, text, submit) {
  const focused = await inPage(tabId, focusField, [ref]);
  if (!focused || focused.error) throw new Error(focused?.error ?? 'Could not find the field.');
  try {
    await withDebugger(tabId);
    await cdp(tabId, 'Input.insertText', { text });
    if (submit) await pressKey(tabId, 'Enter');
  } catch {
    if (!(await inPage(tabId, fallbackType, [ref, text]))) throw new Error(`Could not type into [${ref}].`);
    if (submit) throw new Error('Typed, but Enter could not be pressed in this tab.');
  }
}

// ── Commands from the agents ──────────────────────────────────────────────

async function runCommand(ws, msg) {
  const reply = (body) => {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'result', id: msg.id, ...body }));
  };
  try {
    reply({ ok: true, data: await execute(msg.action, msg.args ?? {}) });
  } catch (err) {
    reply({ ok: false, error: String(err?.message ?? err).slice(0, 500) });
  }
}

async function execute(action, args) {
  const agentId = Number(args.agentId);
  if (!Number.isInteger(agentId)) throw new Error('No agent named in the command.');
  const name = tabName(args.tab);

  if (action === 'open') {
    const url = String(args.url ?? '').trim();
    if (!/^https?:\/\//i.test(url)) throw new Error('Only http(s) addresses can be opened.');
    const existing = await agentTab(agentId, name);
    let tab;
    if (existing) {
      tab = await chrome.tabs.update(existing.id, { url, active: true });
      await chrome.windows.update(tab.windowId, { focused: true }).catch(() => undefined);
    } else {
      tab = await chrome.tabs.create({ url, active: true });
      const map = await tabMap();
      map[`${agentId}:${name}`] = tab.id;
      await saveTabMap(map);
    }
    await sleep(300);
    await waitForLoad(tab.id);
    return { ...(await snapshot(tab.id)), note: existing ? 'navigated' : 'opened a new tab' };
  }

  if (action === 'tabs') {
    const map = await tabMap();
    const tabs = [];
    for (const [key, tabId] of Object.entries(map)) {
      const [owner, tab] = key.split(':');
      if (Number(owner) !== agentId) continue;
      const live = await chrome.tabs.get(tabId).catch(() => null);
      if (live) tabs.push({ name: tab, url: live.url ?? null, title: live.title ?? null });
    }
    return { tabs };
  }

  if (action === 'close') {
    const tab = await agentTab(agentId, name);
    if (!tab) return { closed: false };
    await chrome.tabs.remove(tab.id);
    return { closed: true };
  }

  const tab = await requireTab(agentId, name);
  if (action === 'snapshot') return snapshot(tab.id);
  if (action === 'click') {
    await click(tab.id, Number(args.ref));
  } else if (action === 'type') {
    await type(tab.id, Number(args.ref), String(args.text ?? ''), args.submit === true);
  } else if (action === 'press') {
    await withDebugger(tab.id);
    await pressKey(tab.id, String(args.key ?? ''));
  } else {
    throw new Error(`Unknown action ${action}`);
  }
  await settle(tab.id);
  return snapshot(tab.id);
}

// ── Wiring ────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'session') {
    // Only content.js on the internal app's own pages (manifest matches) sends this; the
    // origin is taken from the SENDER, never from the message.
    let origin = '';
    try {
      origin = new URL(sender.url ?? '').origin;
    } catch {
      return false;
    }
    if (sender.id !== chrome.runtime.id || !sender.tab) return false;
    void onSession(msg.token ?? null, origin);
    return false;
  }
  if (msg?.type === 'get-status') {
    void publicStatus().then(sendResponse);
    return true;
  }
  if (msg?.type === 'reconnect') {
    state.retry = 0;
    disconnect();
    void connect().then(() => sendResponse(true));
    return true;
  }
  return false;
});

// The worker can be stopped by Chrome; an alarm brings the socket back.
chrome.alarms.create('keepalive', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepalive' && !state.ws) void connect();
});

chrome.runtime.onStartup.addListener(() => void connect());
chrome.runtime.onInstalled.addListener(() => void connect());
void connect();
